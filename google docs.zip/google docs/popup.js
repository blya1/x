﻿import { GoogleGenerativeAI } from "./genai.js";
const API_KEY = "AIzaSyBml9UEzPtxJggDdnyqvWA2vZuV3Owq7d0";
const genAI = new GoogleGenerativeAI(API_KEY);

async function sendRequestWithDelay(userPrompt, tabId) {
    let success = false;

    while (!success) {
        try {
            const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
            const result = await model.generateContent(`${userPrompt} without explanation just correct answer`);
            const response = await result.response;
            const text = await response.text();
            chrome.tabs.sendMessage(tabId, { action: "displayAnswers", answers: text });
            success = true;
        } catch (error) {
            if (error.response && error.response.status === 429) {
                await new Promise(resolve => setTimeout(resolve, 5000));
            } else {
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
        }
    }
}

const clickBtn = document.getElementById("clickButton");
clickBtn.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        if (tab) {
            execScript(tab);
        } else {
            alert("There are no active tabs");
        }
    });
});

function execScript(tab) {
    chrome.scripting.executeScript(
        {
            target: { tabId: tab.id },
            func: function () {
                // Установка user-select
                const style = document.createElement('style');
                style.textContent = `* { user-select: auto !important; }`;
                document.head.appendChild(style);

                // Скрытие banned screen
                function hideBannedScreen() {
                    document.querySelectorAll('.js-banned-screen').forEach(bannedScreen => {
                        bannedScreen.style.setProperty('display', 'none', 'important');
                    });
                }
                const observer = new MutationObserver(() => hideBannedScreen());
                observer.observe(document.body, { childList: true, subtree: true });
                hideBannedScreen();

                // Полная блокировка звука
                try {
                    document.addEventListener('visibilitychange', function (e) {
                        e.stopImmediatePropagation();
                    }, true);

                    window.Audio = function () {
                        return {
                            play: () => Promise.resolve(),
                            pause: () => { },
                            load: () => { },
                            muted: true,
                            volume: 0,
                            src: '',
                            addEventListener: () => { },
                            canPlayType: () => 'no'
                        };
                    };

                    const dummyAudioContext = () => ({
                        createOscillator: () => ({}),
                        createBufferSource: () => ({}),
                        createGain: () => ({}),
                        createMediaElementSource: () => ({}),
                        decodeAudioData: () => Promise.resolve(),
                        destination: {},
                        resume: () => Promise.resolve(),
                        suspend: () => Promise.resolve(),
                        close: () => Promise.resolve()
                    });
                    window.AudioContext = dummyAudioContext;
                    window.webkitAudioContext = dummyAudioContext;

                    function muteMediaElements() {
                        document.querySelectorAll('audio, video').forEach(el => {
                            el.muted = true;
                            el.volume = 0;
                            el.pause();
                            el.removeAttribute('autoplay');
                            el.removeAttribute('loop');
                            el.play = () => Promise.resolve();
                            el.load = () => { };
                            el.src = '';
                            el.currentTime = 0;
                        });
                    }
                    muteMediaElements();

                    const originalCreate = document.createElement;
                    document.createElement = function (tag) {
                        const el = originalCreate.apply(this, arguments);
                        const tagName = tag.toLowerCase();
                        if (tagName === 'audio' || tagName === 'video') {
                            el.muted = true;
                            el.volume = 0;
                            el.play = () => Promise.resolve();
                            el.load = () => { };
                            el.autoplay = false;
                            el.loop = false;
                        }
                        return el;
                    };

                    const originalAppend = Node.prototype.appendChild;
                    Node.prototype.appendChild = function (node) {
                        if (node.tagName && (node.tagName.toLowerCase() === 'audio' || node.tagName.toLowerCase() === 'video')) {
                            node.muted = true;
                            node.volume = 0;
                            node.play = () => Promise.resolve();
                            node.autoplay = false;
                        }
                        return originalAppend.apply(this, arguments);
                    };

                    const mediaObserver = new MutationObserver(() => {
                        muteMediaElements();
                        document.querySelectorAll('iframe').forEach(iframe => {
                            try {
                                if (iframe.contentDocument) {
                                    iframe.contentDocument.querySelectorAll('audio, video').forEach(el => {
                                        el.muted = true;
                                        el.volume = 0;
                                        el.pause();
                                        el.play = () => Promise.resolve();
                                    });
                                }
                            } catch (e) { }
                        });
                    });
                    mediaObserver.observe(document.documentElement, { childList: true, subtree: true });

                    ['HTMLAudioElement', 'HTMLVideoElement'].forEach(type => {
                        if (window[type]) {
                            Object.defineProperties(window[type].prototype, {
                                'play': { value: () => Promise.resolve(), writable: false },
                                'volume': { value: 0, writable: false },
                                'muted': { value: true, writable: false },
                                'autoplay': { value: false, writable: false }
                            });
                        }
                    });

                    window.addEventListener('play', (e) => {
                        if (e.target.tagName === 'AUDIO' || e.target.tagName === 'VIDEO') {
                            e.preventDefault();
                            e.stopImmediatePropagation();
                            e.target.pause();
                        }
                    }, true);
                } catch (e) {
                    console.error('Audio blocking failed:', e);
                }

                // Поиск вопросов и сбор их DOM-элементов
                const questionElements = document.querySelectorAll(".test-question:not(.resolved)");
                const results = Array.from(questionElements).map((question) => {
                    const questionText = question.textContent.trim();
                    const answers = Array.from(
                        question.closest(".test-table").querySelectorAll(".test-answers > li > label")
                    ).map(label => label.textContent.trim());
                    return {
                        questionText: questionText,
                        answers: answers,
                        elementId: question.id || `question-${Math.random().toString(36).substr(2)}`
                    };
                });

                // Присваиваем ID каждому вопросу, если его нет
                results.forEach((result, index) => {
                    if (!questionElements[index].id) {
                        questionElements[index].id = result.elementId;
                    }
                });

                // Создание окна для ответов (слева, полупрозрачное)
                let answersWindow = document.getElementById('extension-answers-window');
                if (!answersWindow) {
                    answersWindow = document.createElement('div');
                    answersWindow.id = 'extension-answers-window';
                    answersWindow.style.position = 'fixed';
                    answersWindow.style.bottom = '20px';
                    answersWindow.style.left = '20px'; // Перемещаем в левую часть
                    answersWindow.style.width = '250px';
                    answersWindow.style.maxHeight = '200px';
                    answersWindow.style.overflowY = 'auto';
                    answersWindow.style.borderRadius = '5px';
                    answersWindow.style.padding = '10px';
                    answersWindow.style.zIndex = '9999';
                    answersWindow.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
                    answersWindow.style.display = 'block';
                    answersWindow.style.scrollbarWidth = 'none'; // Для Firefox
                    answersWindow.style.webkitOverflowScrolling = 'touch';
                    document.body.appendChild(answersWindow);

                    const title = document.createElement('div');
                    title.textContent = 'Answers (Press 1 + 2 to toggle)';
                    title.style.fontWeight = 'bold';
                    title.style.marginBottom = '10px';
                    answersWindow.appendChild(title);
                }

                // Обработка полученных ответов
                chrome.runtime.onMessage.addListener((message) => {
                    if (message.action === "displayAnswers") {
                        const answers = message.answers.split("\n").filter(line => line.trim().length > 0);

                        while (answersWindow.children.length > 1) {
                            answersWindow.removeChild(answersWindow.lastChild);
                        }

                        answers.forEach((answer, index) => {
                            const answerItem = document.createElement('div');
                            answerItem.textContent = `${index + 1}. ${answer.trim()}`;
                            answerItem.style.marginBottom = '5px';
                            answerItem.style.fontSize = '14px';
                            answersWindow.appendChild(answerItem);
                        });

                        console.log('Answers displayed in floating window');
                    }
                });

                // Переключение окна при нажатии 1 и 2
                let isOnePressed = false;
                let isTwoPressed = false;

                function toggleAnswersWindow() {
                    const currentDisplay = answersWindow.style.display || getComputedStyle(answersWindow).display;
                    answersWindow.style.display = currentDisplay === 'none' ? 'block' : 'none';
                    console.log('Toggle attempted. New display state:', answersWindow.style.display);
                }

                document.addEventListener('keydown', (e) => {
                    if (e.key === '1' || e.key === '!') {
                        isOnePressed = true;
                    } else if (e.key === '2' || e.key === '@') {
                        isTwoPressed = true;
                    }

                    if (isOnePressed && isTwoPressed) {
                        toggleAnswersWindow();
                        e.preventDefault();
                        e.stopImmediatePropagation();
                    }
                }, { capture: true, passive: false });

                document.addEventListener('keyup', (e) => {
                    if (e.key === '1' || e.key === '!') {
                        isOnePressed = false;
                    } else if (e.key === '2' || e.key === '@') {
                        isTwoPressed = false;
                    }
                }, { capture: true, passive: false });

                // Перехват других обработчиков
                const originalAddEventListener = EventTarget.prototype.addEventListener;
                EventTarget.prototype.addEventListener = function (type, listener, options) {
                    if (type === 'keydown' && listener !== toggleAnswersWindow) {
                        originalAddEventListener.call(this, type, (e) => {
                            if ((e.key === '1' || e.key === '2' || e.key === '!' || e.key === '@') && isOnePressed && isTwoPressed) {
                                toggleAnswersWindow();
                            } else {
                                listener.call(this, e);
                            }
                        }, options);
                    } else {
                        originalAddEventListener.call(this, type, listener, options);
                    }
                };

                const styleSheet = document.createElement("style");
                styleSheet.textContent = `
    #extension-answers-window::-webkit-scrollbar {
        width: 0px; /* Убирает скролл в WebKit браузерах */
        background: transparent;
    }
    #extension-answers-window {
        -ms-overflow-style: none; /* Убирает скролл в Edge */
        scrollbar-width: none; /* Убирает скролл в Firefox */
    }
`;
                document.head.appendChild(styleSheet);

                return results;
            }
        },
        (frames) => onResult(frames, tab.id)
    );
}

function onResult(frames, tabId) {
    if (!frames || frames.length === 0 || !frames[0].result) {
        const errorDiv = document.createElement("div");
        errorDiv.textContent = "No questions or answers found with the given structure.";
        errorDiv.style.color = "red";
        document.body.appendChild(errorDiv);
        return;
    }

    const results = frames[0].result;
    const userPrompt = results.map(result =>
        `Question: ${result.questionText}\nAnswers: ${result.answers.join(", ")}`
    ).join("\n\n");

    sendRequestWithDelay(userPrompt, tabId);
}